#Term Project Graphics
from cmu_112_graphics import *

import math, random

from ObstacleClasses import *
from Enemies import *

def appStarted(app):
    app.mode = 'menuMode'
    #Referenced from the 112 Notes on Modes.
    gameplayMode_appStarted(app)

#Referenced from Sidescroller from Animations Part 4 Notes.

def gameplayMode_appStarted(app):
    app.i = 0
    # app.x1 = app.width//6 -
    app.scrollX = 0
    app.dots = [(random.randrange(4*app.width//5, app.width),
                random.randrange(60, app.height))]
    app.r = 20
    app.jump = False
    app.velocityY = 0
    app.posX = app.width
    app.posY = app.height - 10
    app.baseY = app.posY
    app.isGameOver = False
    app.rectangle = Rectangle(app.posX, app.posY, 'Red')
    app.bullets = Bullet(app.posX, app.posY, 'Black')
    app.image = app.loadImage('cartoon-map-bear-baby-clipart-png-image-removebg-preview.png')
    #Got this image from https://pikbest.com/png-images/pngtree-cartoon-map-bear-baby-clipart_5880728.html
    app.image = app.scaleImage(app.image, 1/5)
    #Got this image from https://www.kindpng.com/imgv/ibTxTim_enemy-sprite-sheet-sprite-sheet-enemy-png-transparent/
    app.sprite = Sprite(app.width//6, app.posY - app.r/2, app.width, app.height,
    ImageTk.PhotoImage(app.image))
    app.obstaclespacing = 10 * random.randint(0, 20)
    spritestrip = app.loadImage('kindpng_2266291-removebg-preview.png')
    app.sprites = []
    for i in range(3):
        sprite = spritestrip.crop((30+260*i, 0, 230 + 260*i, 500))
        sprite = app.scaleImage(sprite, 1/3)
        app.sprites.append(sprite)
    app.spriteCounter = 0
    app.zombiepositions = []
    app.counter = 0

def gameplayMode_timerFired(app):
    if not app.isGameOver:
        app.counter += 1
        genfrequency = random.randint(15, 40)
        if app.counter % genfrequency == 0:
            app.zombiepositions.append(gameplayMode_getZombie(app))
        for zombie in app.zombiepositions:
            zombie.update(app.i + 1)
            app.i += 1
        app.spriteCounter = (1 + app.spriteCounter) % len(app.sprites)
        app.scrollX += 10
        app.posX += app.scrollX
        if app.jump:
            app.sprite.jump(5)
            while app.sprite.getycoords() != app.posY - app.r/2:
                app.counter += 1
                app.sprite.jump(5)
            app.sprite.resetvelocity()
            app.posY += app.velocityY
            app.velocityY += 5
            if app.posY == app.baseY:
                app.jump = False
            
            app.jump = False
        app.dots += [(random.randrange(app.posX, app.posX + 10),
                random.randrange(3*app.height/4, app.height))]
        for zombie in app.zombiepositions:
            coords = zombie.getcoords()
            if (coords[0]<app.width//6<coords[2]) and (coords[1]<app.posY-app.r/2
            <coords[3]):
                app.isGameOver = True

def gameplayMode_keyPressed(app, event):
    if not app.isGameOver:
        if (event.key == "Right"): app.scrollX += 15
        if (event.key == "Up") and app.jump == False:
            app.velocityY = -30
            app.jump = True

def getPlayer(app):
    return (app.width//9, app.posY-3*app.r, app.width//9 + 4*app.r, app.posY)

def gameplayMode_getZombie(app):
    return Zombie(app.width, app.height-30, (app.sprites))

# def gameplayMode_redrawZombie(app, canvas):
#     sprite = app.sprites[app.spriteCounter]
#     sprite = app.scaleImage(sprite, 1/3)
#     another = Zombie(app.width - app.scrollX, app.height - 30,
#         ImageTk.PhotoImage(sprite))
#     return another.draw(canvas)

def gameplayMode_redrawAll(app, canvas):
    canvas.create_rectangle(0, app.height, app.width, app.height - 10, fill =
    'black')
    sprite = app.sprites[app.spriteCounter]
    sprite = app.scaleImage(sprite, 1/3)
    canvas.create_rectangle(app.width//9, app.posY-3*app.r, app.width//9 +
    4*app.r, app.posY)
    for zombie in app.zombiepositions:
        zombie.draw(canvas)
    for (cx, cy) in app.dots:
        cx -= app.scrollX
        canvas.create_oval(cx-10, cy-10, cx+10, cy+10, fill='lightGreen')
        app.rectangle.draw(canvas, cx)
        app.bullets.draw(canvas, cx)
    # canvas.create_image(app.width//6, app.posY - app.r/2, image = 
    # ImageTk.PhotoImage(app.image))
    app.sprite.draw(canvas)
    if app.isGameOver:
        canvas.create_rectangle(0, 0, app.width, app.height, fill = 'Blue')
        canvas.create_text(app.width//2, app.height//2, text = 'Game Over',
        font = 'Helvetica 30')

def menuMode_redrawAll(app, canvas):
    canvas.create_rectangle(0, 0, app.width, app.height, fill = 'Blue')
    canvas.create_text(app.width//2, app.height//2, text='Press space to play',
    font = 'Helvetica 40', fill = 'Black')

def menuMode_keyPressed(app, event):
    if (event.key == 'Space'):
        app.mode = 'gameplayMode'

class Sprite:
    def __init__(self, x, y, width, height, image):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.image = image
        self.velocityY = -35
        self.basey = y
    def jump(self, a):
        self.velocityY += a
        print(self.y)
        self.y += self.velocityY
    def draw(self, canvas):
        canvas.create_image(self.x, self.y, image = self.image)
    def getycoords(self):
        return self.y
    def resetvelocity(self):
        self.velocityY = -35

def main():
    runApp(width = 800, height = 400)

if __name__ == '__main__':
    main()