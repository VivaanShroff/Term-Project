from cmu_112_graphics import *
from Menu import *
from Gameplay import *
from BirdClass import *
from w import *
from ObstacleClasses import *

def appStarted(app):
    app.mode = 'menuMode'
    gameplayMode_appStarted(app)
def main():
    runApp(width = 800, height = 400)

if __name__ == '__main__':
    main()
