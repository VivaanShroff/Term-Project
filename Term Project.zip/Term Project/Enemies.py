from cmu_112_graphics import *

from Main import *
from ObstacleClasses import *

class Enemy:
    def __init__(self, x, y, sprites):
        self.x = x
        self.y = y
        self.sprites = sprites
        self.image = self.sprites[0]

class Zombie(Enemy):
    def __init__(self, x, y, sprites):
        super().__init__(x, y, sprites)
        self.scroll = 10
    def draw(self, canvas):
        canvas.create_image(self.x, self.y, image = ImageTk.PhotoImage(self.image))
        canvas.create_rectangle(self.x-20, self.y-80, self.x+10, self.y+25)
    def update(self, i):
        self.image = self.sprites[i%len(self.sprites)]
        self.x -= self.scroll
    def getxcoords(self):
        return self.x

class Bird(Zombie):
    def __init__(self, x, y, end, image):
        super().__init__(x, y, image)
        self.end = end
        self.velocity = -10
        self.fly = [self.x, self.end]
    def draw(self, canvas):
        canvas.create_image(self.x, self.y, image = ImageTk.PhotoImage(self.image))
    def update(self, i):
        self.image = self.sprites[i%len(self.sprites)]
    #Got this from https://www.techwithtim.net/tutorials/game-development-with-python/pygame-tutorial/pygame-enemies/
    def firstmove(self):
        if self.x == self.fly[0]:
            self.x += self.velocity
    def move(self):
        if self.velocity < 0:
            if self.x + self.velocity > self.fly[1]:
                self.image = self.sprites[0]
                self.x += self.velocity
            else:
                self.velocity = self.velocity * -1
    def moveback(self):
        if self.velocity > 0:
            if self.x + self.velocity < self.fly[0]:
                self.image = self.sprites[0]
                self.x += self.velocity
            else:
                self.velocity = self.velocity * -1