from cmu_112_graphics import *

from Main import *
from ObstacleClasses import *

def appStartedw(app):
    spritestrip = app.loadImage('kindpng_2266291-removebg-preview.png')
    app.sprites = []
    for i in range(3):
        sprite = spritestrip.crop((30+260*i, 0, 230 + 260*i, 500))
        app.sprites.append(sprite)
    app.spriteCounter = 0
    app.zombiepositions = []

def timerFiredw(app):
    app.spriteCounter = (1 + app.spriteCounter) % len(app.sprites)

def redrawAllw(app, canvas, cx):
    sprite = app.sprites[app.spriteCounter]
    sprite = app.scaleImage(sprite, 1/3)
    another = Zombie(app.width//2 + cx, app.height-30,
    ImageTk.PhotoImage(sprite))
    another.draw(canvas)
    # app.zombiepositions.append(another)
    # canvas.create_image(app.width//2 + cx, app.height-30,
    # image = ImageTk.PhotoImage(sprite))

class Enemy:
    def __init__(self, x, y, sprites):
        self.x = x
        self.y = y
        self.sprites = sprites
        self.image = self.sprites[0]

class Zombie(Enemy):
    def __init__(self, x, y, sprites):
        super().__init__(x, y, sprites)
        self.boundaries = (self.x-20, self.y-80, self.x+10, self.y+25)
        self.scroll = 10
    def draw(self, canvas):
        canvas.create_image(self.x, self.y, image = ImageTk.PhotoImage(self.image))
        canvas.create_rectangle(self.x-20, self.y-80, self.x+10, self.y+25)
    def update(self, i):
        self.image = self.sprites[i%len(self.sprites)]
        self.x -= self.scroll
    def getcoords(self):
        return self.boundaries

class Bird(Zombie):
    def __init__(self, x, y, image):
        super().__init__(x, y, image)


def appStarted(app):
    sprites = app.loadImage('226-2266489_enemy-sprite-sheet-enemy-sprite-sheet-png-transparent-removebg-preview.png')
    #Got this image from https://www.kindpng.com/imgv/ibTxbih_enemy-sprite-sheet-enemy-sprite-sheet-png-transparent/
    app.sprite2 = []
    for i in range(2):
        sprite2 = sprites.crop((60+260*i, 0, 430+260*i, 500))
        app.sprite2.append(sprite2)
    app.spritecount = 0

def timerFired(app):
    app.spritecount = (1+ app.spritecount) % len(app.sprite2)

def redrawAll(app, canvas):
    sprite2 = app.sprite2[app.spritecount]
    sprite2 = app.scaleImage(sprite2, 1/3)
    # canvas.create_image(app.width//2, app.height//2,
    # image = ImageTk.PhotoImage(sprite2))

#runApp(width = 400, height = 400)