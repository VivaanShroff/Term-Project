from cmu_112_graphics import *

from Main import *
from ObstacleClasses import *

def appStarted(app):
    sprites = app.loadImage('https://www.kindpng.com/picc/m/226-2266489_enemy-sprite-sheet-enemy-sprite-sheet-png-transparent.png')
    #Got this image from https://www.kindpng.com/imgv/ibTxbih_enemy-sprite-sheet-enemy-sprite-sheet-png-transparent/
    app.sprite2 = []
    for i in range(2):
        sprite2 = sprites.crop((60+260*i, 0, 430+260*i, 500))
        app.sprite2.append(sprite2)
    app.spritecount = 0

def timerFired(app):
    app.spritecount = (1+ app.spritecount) % len(app.sprite2)

def redrawAll(app, canvas):
    sprite2 = app.sprite2[app.spritecount]
    sprite2 = app.scaleImage(sprite2, 1/3)
    canvas.create_image(app.width//2, app.height//2,
    image = ImageTk.PhotoImage(sprite2))

runApp(width = 400, height = 400)