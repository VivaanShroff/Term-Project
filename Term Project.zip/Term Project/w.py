from cmu_112_graphics import *

from Main import *
from ObstacleClasses import *

def appStartedw(app):
    spritestrip = app.loadImage('https://www.kindpng.com/picc/m/226-2266291_enemy-sprite-sheet-sprite-sheet-enemy-png-transparent.png')
    app.sprites = []
    for i in range(3):
        sprite = spritestrip.crop((30+260*i, 0, 230 + 260*i, 500))
        app.sprites.append(sprite)
    app.spriteCounter = 0

def timerFiredw(app):
    app.spriteCounter = (1 + app.spriteCounter) % len(app.sprites)

def redrawAllw(app, canvas, cx):
    sprite = app.sprites[app.spriteCounter]
    sprite = app.scaleImage(sprite, 1/3)
    another = Zombie(app.width//2 + cx, app.height-30,
    ImageTk.PhotoImage(sprite))
    another.draw(canvas)
    # canvas.create_image(app.width//2 + cx, app.height-30,
    # image = ImageTk.PhotoImage(sprite))

class Zombie:
    def __init__(self, x, y, image):
        self.x = x
        self.y = y
        self.image = image
    def draw(self, canvas):
        canvas.create_image(self.x, self.y, image = self.image)

class Bird(Zombie):
    def __init__(self, x, y, image):
        super().__init__(x, y, image)

#runApp(width = 400, height = 400)