from cmu_112_graphics import *
from Gameplay import *


def menuMode_redrawAll(app, canvas):
    
    canvas.create_rectangle(0, 0, app.width, app.height, fill = 'Blue')
    canvas.create_text(app.width//2, app.height//2, text = 'Menu',
    font = 'Helvetica 40', fill = 'Black')

def menuMode_keyPressed(app, event):
    if (event.key == 'Space'):
        app.mode = 'gameplayMode'